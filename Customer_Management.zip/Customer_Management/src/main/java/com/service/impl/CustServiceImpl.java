package com.service.impl;


import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import com.dao.impl.EmployeeDao;
//SERVICE IS THE MIDDLE LAYER

@Service//get from @repository and connects to @controller

@Transactional//database transaction

public class CustServiceImpl{

 @Autowired

 private EmployeeDao employeeDAO1;

 @Transactional

 public void deleteemps(int theId)

 {

	 System.out.println("here");
	 System.out.println(theId);
 employeeDAO1.deleteEmp(theId);
 
 
 }

}