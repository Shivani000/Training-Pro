package com.dao.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pojo.Customer;

public class EmployeeDao {

	private Configuration conf;
	private SessionFactory sf;
	private Session session;
	private Transaction tx;
	
	@SuppressWarnings("deprecation")
	public void saveData(Customer e) {
		
		conf = new Configuration().configure("cts_hibernate.cfg.xml");
		sf = conf.buildSessionFactory();
		session = sf.openSession();
		tx= session.beginTransaction();
		session.save(e);
		tx.commit();
	}
	
	
	
	
	
	
	//update data
	@SuppressWarnings("deprecation")
	public void updateData(Customer emp) {
		
		conf = new Configuration().configure("cts_hibernate.cfg.xml");
		sf = conf.buildSessionFactory();
		session = sf.openSession();
		tx= session.beginTransaction();
		Customer obj = (Customer) session.get(Customer.class, emp.getCust_id());
		 obj.setCemail(emp.getCemail());
		 obj.setCfname(emp.getCfname());
		 obj.setCaddress(emp.getCaddress());
		 session.update(obj);
		 tx.commit();
	}

	
	
	
	
	
	
	
	public void deleteEmp(int theId)
	{
		conf = new Configuration().configure("cts_hibernate.cfg.xml");
		sf = conf.buildSessionFactory();
		Session session = sf.openSession();
		//:abc runtime variable
		Query theQuery = session.createQuery("delete from Customer as c where c.cust_id=?");
		theQuery.setParameter(0, theId);
		theQuery.executeUpdate();
	}
	
	
	//search data
	public List searchData(Customer e) {
		List li = new ArrayList();
		conf = new Configuration().configure("cts_hibernate.cfg.xml");
		sf = conf.buildSessionFactory();
		session = sf.openSession();
		tx= session.beginTransaction();
		List list = session.createQuery("from Customer").list();
		Iterator it = list.iterator();
		while(it.hasNext())
		{
			Customer emp = (Customer)it.next();
			if(e.getCfname().equalsIgnoreCase(emp.getCfname()))
			{
				Customer obj = new Customer();
				obj.setCfname(emp.getCfname());
				obj.setCemail(emp.getCemail());
				obj.setCage(emp.getCage());
				obj.setCaddress(emp.getCaddress());
				li.add(obj);
			}
			
		}
		return li;

	}
	
	
	

		@SuppressWarnings({ "deprecation", "rawtypes" })
	public List login(String email, String pass) {
		conf = new Configuration().configure("cts_hibernate.cfg.xml");
		sf = conf.buildSessionFactory();
		session = sf.openSession();
		String sql="from Customer  as e where e.cemail=? and e.cpass=?";
		Query query1= session.createQuery(sql);
		query1.setParameter(0, email);
		query1.setParameter(1, pass);
		List list = query1.list();
		return list;
	}

	@SuppressWarnings("deprecation")
	public List displayData() {
		conf = new Configuration().configure("cts_hibernate.cfg.xml");
		sf = conf.buildSessionFactory();
		session = sf.openSession();
		tx= session.beginTransaction();
		List list = session.createQuery("from Customer").list();
		return list;
	}
	
	
	
	
	
	}
