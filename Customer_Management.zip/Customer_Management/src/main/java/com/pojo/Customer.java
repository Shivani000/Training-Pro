package com.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//import javax.validation.constraints.Min;
//import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Controller;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Controller
@Entity
@Table(name="customer_info")
public class Customer {

	@Id
	@Column(name="cust_id")
	@GeneratedValue //autoincrement
	private int cust_id;
	
	@SuppressWarnings("deprecation")
	@Size(max = 20, min = 3, message = "Name length must be between {2} and {1} characters")
	@NotEmpty(message = "Please enter name")
	@Column(name="cust_name")
	private String cname;
	
	
	@Column(name="cust_fname")
	private String cfname;
	
	@Column(name="cust_lname")
	private String clname;
	
	@NotEmpty(message = "Please enter valid email")
	@Column(name="cust_email")
	private String cemail;
	
	@Column(name="cust_address")
	private String caddress;
	
	@NotEmpty(message = "Please enter password")
	
	@Column(name="cust_pass")
	private String cpass;
	
	@Column(name="gender")
	private String gender;
	
	@Min(value=21, message="Age Must be equal or greater than 21") 
	@Column(name="cust_age")
	private int cage;
	
	public int getCage() {
		return cage;
	}

	public void setCage(int cage) {
		this.cage = cage;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public String getCfname() {
		return cfname;
	}

	public void setCfname(String cfname) {
		this.cfname = cfname;
	}

	public String getClname() {
		return clname;
	}

	public void setClname(String clname) {
		this.clname = clname;
	}

	public String getCemail() {
		return cemail;
	}

	public void setCemail(String cemail) {
		this.cemail = cemail;
	}

	public String getCpass() {
		return cpass;
	}

	public void setCpass(String cpass) {
		this.cpass = cpass;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	

	
	
}
