package com.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.impl.EmployeeDao;
import com.pojo.Customer;
import com.service.impl.CustServiceImpl;



@Controller
public class ControllerDao {

	private ApplicationContext conn;
	
	@RequestMapping("/register1")
	public String view2(Model m )
	{
		conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Customer  emp = conn.getBean("info", Customer.class);
		m.addAttribute("bean",emp);
		return "register";
	}
	
	@RequestMapping("/cont")
	public String view()
	{
		return "cont";
	}
	
	@RequestMapping("/query")
	public String view4()
	{
		return "query";
	}
	
	@RequestMapping("/about1")
	public String view5()
	{
		return "about1";
	}
	
	
	@RequestMapping("/terms1")
	public String view6()
	{
		return "terms1";
	}
	
	
	@RequestMapping("/save")
	public String view3(@Validated @ModelAttribute("bean") Customer e,Model m ,BindingResult br)
	{
		
		if(br.hasErrors())  
        {  
            return "register";  
        }  
		else
		{
			conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
			EmployeeDao obj = conn.getBean("dao", EmployeeDao.class);
		
		obj.saveData(e);
		m.addAttribute("msg", "Registered succesfully..");
		return "register";
	}}
//display
	
	@RequestMapping("/display")	
	public String view191(Model m )
	{		
		conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		EmployeeDao  obj = conn.getBean("dao", EmployeeDao.class);
		List list  = obj.displayData();
		if(!list.isEmpty())
		{
			m.addAttribute("data",list);
		}
		else {
		m.addAttribute("msg", "no data found..");
		}
		return "display";
	}
	
	
	
	@RequestMapping("/update1")
	public String view314(@ModelAttribute("bean") Customer emp, Model m)
	{
		conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		EmployeeDao obj = conn.getBean("dao", EmployeeDao.class);
		obj.updateData(emp);
		m.addAttribute("msg2", "Successfully Updated..");

		return "home1";


	}
	
	
	
	
	
	
	 private CustServiceImpl employeeService1;
	//deletion

	  @RequestMapping(value="/deleteemps/{cust_id}",method = RequestMethod.GET)   

	  public String delemp(

	   @PathVariable("cust_id")

	   int cust_id)

	  {   
		 System.out.println(cust_id);

		 EmployeeDao  obj2=new EmployeeDao();
		 obj2.deleteEmp(cust_id);
	    return "redirect:/display"; //call req pattern /view

	  } 
	  
	  
	  @RequestMapping("/find")
		public String view33(Model m)
		{
			conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
			Customer emp = conn.getBean("info", Customer.class);
			m.addAttribute("bean",emp);
			return "search";
		}
	  

	  
	  @RequestMapping("/search1")
		public String view34(@ModelAttribute("bean") Customer e,Model m,HttpServletRequest request)
		{
			conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
			HttpSession session = request.getSession();
			Customer use = (Customer)session.getAttribute("sdata");
			
			EmployeeDao obj = conn.getBean("dao", EmployeeDao.class);
			List list = obj.searchData(e);
			if(!list.isEmpty())
			{
				m.addAttribute("li", list);
			}
			else 
			{
				m.addAttribute("msg1","no record found..");
			}
			return "search";
		}
			
		
	  
	  
	  
	  
	

	//login
	
	@RequestMapping("/login1")
	public String view51(Model m)
	{
		conn = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Customer  obj = conn.getBean("info", Customer.class);
		m.addAttribute("bean",obj);
		return "login";
	}
   
	@RequestMapping("/logindata")
	public String login21(@ModelAttribute("bean") Customer  obj ,HttpServletRequest request,HttpServletResponse response,Model m) {
		
		// =  new Customer();
		obj.setCemail(request.getParameter("cemail"));
		obj.setCpass(request.getParameter("cpass"));
		
		String email = obj.getCemail();
		String pass = obj.getCpass();

		EmployeeDao  obj1 =  new EmployeeDao();
		
		List list = obj1.login(email,pass);
		if((list!=null) && (list.size()>0))
		{
			return "home";
		}
		else{
			m.addAttribute("msg","Please enter correct details");
			
		}
			//return "redirect:index.jsp";	
			return "login";
		}
	
	
	
	
}
