function popup()

{ 

 alert("Thank You For accepting our terms and conditions!!");

}

function verify()
{

	if(document.form1.p1.value.lengt<6)
		{
		alert("Enter Username");
		document.form1.p1.focus();
		return false;
		}
}